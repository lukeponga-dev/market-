// Main JavaScript for Tor Marketplace

// Import Alpine.js components
import Alpine from 'alpinejs';

// Define Alpine.js data and components
document.addEventListener('alpine:init', () => {
  // Auth component
  Alpine.data('auth', () => ({
    isAuthenticated: false,
    user: null,
    loginForm: {
      username: '',
      password: '',
      error: ''
    },
    registerForm: {
      username: '',
      password: '',
      confirmPassword: '',
      email: '',
      pgpPublicKey: '',
      error: ''
    },
    showLoginModal: false,
    showRegisterModal: false,
    showTwoFactorModal: false,
    twoFactorCode: '',
    twoFactorUserId: null,

    init() {
      // Check if user is already logged in
      this.checkAuth();
    },

    async checkAuth() {
      try {
        const response = await fetch('/api/auth/me');
        const data = await response.json();

        if (data.success) {
          this.isAuthenticated = true;
          this.user = data.user;
        } else {
          this.isAuthenticated = false;
          this.user = null;
        }
      } catch (error) {
        console.error('Auth check error:', error);
        this.isAuthenticated = false;
        this.user = null;
      }
    },

    async login() {
      if (!this.loginForm.username || !this.loginForm.password) {
        this.loginForm.error = 'Username and password are required';
        return;
      }

      try {
        const response = await fetch('/api/auth/login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            username: this.loginForm.username,
            password: this.loginForm.password
          })
        });

        const data = await response.json();

        if (data.success) {
          this.isAuthenticated = true;
          this.user = data.user;
          this.showLoginModal = false;
          this.loginForm = { username: '', password: '', error: '' };
          window.location.reload();
        } else if (data.requireTwoFactor) {
          this.twoFactorUserId = data.user?.id;
          this.showLoginModal = false;
          this.showTwoFactorModal = true;
        } else {
          this.loginForm.error = data.message || 'Invalid username or password';
        }
      } catch (error) {
        console.error('Login error:', error);
        this.loginForm.error = 'An error occurred during login';
      }
    },

    async verifyTwoFactor() {
      if (!this.twoFactorCode) {
        return;
      }

      try {
        const response = await fetch('/api/auth/verify-2fa', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            userId: this.twoFactorUserId,
            code: this.twoFactorCode
          })
        });

        const data = await response.json();

        if (data.success) {
          this.isAuthenticated = true;
          this.user = data.user;
          this.showTwoFactorModal = false;
          this.twoFactorCode = '';
          this.twoFactorUserId = null;
          window.location.reload();
        } else {
          this.twoFactorError = data.message || 'Invalid code';
        }
      } catch (error) {
        console.error('2FA verification error:', error);
        this.twoFactorError = 'An error occurred during verification';
      }
    },

    async register() {
      // Validate form
      if (!this.registerForm.username || !this.registerForm.password) {
        this.registerForm.error = 'Username and password are required';
        return;
      }

      if (this.registerForm.password !== this.registerForm.confirmPassword) {
        this.registerForm.error = 'Passwords do not match';
        return;
      }

      if (this.registerForm.password.length < 8) {
        this.registerForm.error = 'Password must be at least 8 characters';
        return;
      }

      try {
        const response = await fetch('/api/auth/register', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            username: this.registerForm.username,
            password: this.registerForm.password,
            email: this.registerForm.email || undefined,
            pgp_public_key: this.registerForm.pgpPublicKey || undefined
          })
        });

        const data = await response.json();

        if (data.success) {
          this.showRegisterModal = false;
          this.showLoginModal = true;
          this.registerForm = {
            username: '',
            password: '',
            confirmPassword: '',
            email: '',
            pgpPublicKey: '',
            error: ''
          };
          alert('Registration successful! Please log in.');
        } else {
          this.registerForm.error = data.message || 'Registration failed';
        }
      } catch (error) {
        console.error('Registration error:', error);
        this.registerForm.error = 'An error occurred during registration';
      }
    },

    async logout() {
      try {
        await fetch('/api/auth/logout', { method: 'POST' });
        this.isAuthenticated = false;
        this.user = null;
        window.location.href = '/';
      } catch (error) {
        console.error('Logout error:', error);
      }
    }
  }));

  // Product listing component
  Alpine.data('productListing', () => ({
    products: [],
    categories: [],
    selectedCategory: null,
    searchQuery: '',
    currentPage: 1,
    totalPages: 1,
    loading: true,
    error: null,

    init() {
      this.fetchCategories();
      this.fetchProducts();
    },

    async fetchCategories() {
      try {
        const response = await fetch('/api/categories');
        const data = await response.json();

        if (data.success) {
          this.categories = data.categories;
        }
      } catch (error) {
        console.error('Error fetching categories:', error);
      }
    },

    async fetchProducts() {
      this.loading = true;
      this.error = null;

      try {
        // Build query parameters
        const params = new URLSearchParams();
        if (this.searchQuery) params.append('query', this.searchQuery);
        if (this.selectedCategory) params.append('category_id', this.selectedCategory);
        params.append('page', this.currentPage);
        params.append('limit', 12);

        const response = await fetch(`/api/products?${params.toString()}`);
        const data = await response.json();

        if (data.success) {
          this.products = data.products;
          this.totalPages = data.pages;
        } else {
          this.error = data.message || 'Failed to fetch products';
        }
      } catch (error) {
        console.error('Error fetching products:', error);
        this.error = 'An error occurred while fetching products';
      } finally {
        this.loading = false;
      }
    },

    selectCategory(categoryId) {
      this.selectedCategory = categoryId === this.selectedCategory ? null : categoryId;
      this.currentPage = 1;
      this.fetchProducts();
    },

    search() {
      this.currentPage = 1;
      this.fetchProducts();
    },

    goToPage(page) {
      if (page < 1 || page > this.totalPages) return;
      this.currentPage = page;
      this.fetchProducts();
      window.scrollTo(0, 0);
    }
  }));

  // Product detail component
  Alpine.data('productDetail', () => ({
    product: null,
    loading: true,
    error: null,
    activeImageIndex: 0,
    quantity: 1,

    init() {
      const productSlug = window.location.pathname.split('/').pop();
      if (productSlug) {
        this.fetchProduct(productSlug);
      }
    },

    async fetchProduct(slug) {
      this.loading = true;
      this.error = null;

      try {
        const response = await fetch(`/api/products/slug/${slug}`);
        const data = await response.json();

        if (data.success) {
          this.product = data.product;
        } else {
          this.error = data.message || 'Product not found';
        }
      } catch (error) {
        console.error('Error fetching product:', error);
        this.error = 'An error occurred while fetching the product';
      } finally {
        this.loading = false;
      }
    },

    setActiveImage(index) {
      this.activeImageIndex = index;
    }
  }));

  // Payment component
  Alpine.data('payment', () => ({
    payment: null,
    loading: false,
    error: null,
    checkingStatus: false,
    pollInterval: null,

    async generatePayment(currency, amount, paymentFor) {
      this.loading = true;
      this.error = null;

      try {
        const response = await fetch('/api/payments/generate', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            currency,
            amount,
            paymentFor
          })
        });

        const data = await response.json();

        if (data.success) {
          this.payment = data.payment;
          this.startPolling(data.payment.payment_id);
        } else {
          this.error = data.message || 'Failed to generate payment';
        }
      } catch (error) {
        console.error('Payment generation error:', error);
        this.error = 'An error occurred while generating payment';
      } finally {
        this.loading = false;
      }
    },

    async checkPaymentStatus(paymentId) {
      if (this.checkingStatus) return;
      this.checkingStatus = true;

      try {
        const response = await fetch(`/api/payments/status/${paymentId}`);
        const data = await response.json();

        if (data.success) {
          this.payment = data.payment;

          // If payment is confirmed or completed, stop polling
          if (this.payment.status === 'confirmed' || this.payment.status === 'completed') {
            this.stopPolling();

            // Redirect or update UI based on payment completion
            if (this.payment.payment_for.startsWith('order:')) {
              alert('Payment confirmed! Your order has been processed.');
              window.location.href = '/account/orders';
            }
          }
        }
      } catch (error) {
        console.error('Payment status check error:', error);
      } finally {
        this.checkingStatus = false;
      }
    },

    startPolling(paymentId) {
      // Check status immediately
      this.checkPaymentStatus(paymentId);

      // Then poll every 30 seconds
      this.pollInterval = setInterval(() => {
        this.checkPaymentStatus(paymentId);
      }, 30000);
    },

    stopPolling() {
      if (this.pollInterval) {
        clearInterval(this.pollInterval);
        this.pollInterval = null;
      }
    },

    // Development only - simulate payment
    async simulatePayment(paymentId) {
      try {
        const response = await fetch('/api/payments/simulate-confirmation', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ paymentId })
        });

        const data = await response.json();

        if (data.success) {
          this.checkPaymentStatus(paymentId);
        }
      } catch (error) {
        console.error('Payment simulation error:', error);
      }
    }
  }));
});

// Start Alpine.js
window.Alpine = Alpine;
Alpine.start();
