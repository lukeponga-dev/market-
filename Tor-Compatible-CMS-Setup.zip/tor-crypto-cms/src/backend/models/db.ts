import sqlite3 from 'sqlite3';
import { open, Database } from 'sqlite';
import fs from 'fs';
import path from 'path';
import bcrypt from 'bcrypt';
import dotenv from 'dotenv';

dotenv.config();

// Ensure data directory exists
const dataDir = path.resolve('./data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = process.env.DB_PATH || './data/marketplace.db';

// Database connection
export let db: Database;

export const initializeDatabase = async (): Promise<void> => {
  db = await open({
    filename: dbPath,
    driver: sqlite3.Database,
  });

  // Enable foreign keys
  await db.exec('PRAGMA foreign_keys = ON');

  // Create tables if they don't exist
  await db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      pgp_public_key TEXT,
      email TEXT UNIQUE,
      role TEXT NOT NULL DEFAULT 'user',
      vendor BOOLEAN DEFAULT 0,
      twofa_secret TEXT,
      twofa_enabled BOOLEAN DEFAULT 0,
      reputation INTEGER DEFAULT 0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      description TEXT,
      parent_id INTEGER,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (parent_id) REFERENCES categories (id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      description TEXT NOT NULL,
      short_description TEXT,
      price DECIMAL(18,8) NOT NULL,
      currency TEXT NOT NULL DEFAULT 'BTC',
      stock INTEGER DEFAULT -1,
      vendor_id INTEGER NOT NULL,
      category_id INTEGER,
      status TEXT NOT NULL DEFAULT 'draft',
      shipping_options TEXT, -- JSON string
      digital BOOLEAN DEFAULT 0,
      featured BOOLEAN DEFAULT 0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (vendor_id) REFERENCES users (id) ON DELETE CASCADE,
      FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS product_images (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL,
      image_path TEXT NOT NULL,
      main_image BOOLEAN DEFAULT 0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      buyer_id INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      total_price DECIMAL(18,8) NOT NULL,
      currency TEXT NOT NULL,
      shipping_address TEXT ENCRYPTED, -- Encrypted shipping info
      notes TEXT,
      payment_id TEXT UNIQUE NOT NULL,
      escrow BOOLEAN DEFAULT 1,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (buyer_id) REFERENCES users (id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      quantity INTEGER NOT NULL DEFAULT 1,
      price DECIMAL(18,8) NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (order_id) REFERENCES orders (id) ON DELETE CASCADE,
      FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sender_id INTEGER NOT NULL,
      recipient_id INTEGER NOT NULL,
      content TEXT ENCRYPTED NOT NULL,
      read BOOLEAN DEFAULT 0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (sender_id) REFERENCES users (id) ON DELETE CASCADE,
      FOREIGN KEY (recipient_id) REFERENCES users (id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS disputes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER UNIQUE NOT NULL,
      opened_by INTEGER NOT NULL,
      reason TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'open',
      resolution TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (order_id) REFERENCES orders (id) ON DELETE CASCADE,
      FOREIGN KEY (opened_by) REFERENCES users (id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS reviews (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      order_id INTEGER NOT NULL,
      rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
      content TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
      FOREIGN KEY (order_id) REFERENCES orders (id) ON DELETE CASCADE,
      UNIQUE(user_id, order_id)
    );

    CREATE TABLE IF NOT EXISTS payment_addresses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      currency TEXT NOT NULL,
      address TEXT NOT NULL,
      payment_for TEXT NOT NULL,
      payment_id TEXT NOT NULL UNIQUE,
      amount DECIMAL(18,8) NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      confirmations INTEGER DEFAULT 0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- Triggers to update timestamps
    CREATE TRIGGER IF NOT EXISTS update_users_timestamp
    AFTER UPDATE ON users
    BEGIN
      UPDATE users SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
    END;

    CREATE TRIGGER IF NOT EXISTS update_categories_timestamp
    AFTER UPDATE ON categories
    BEGIN
      UPDATE categories SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
    END;

    CREATE TRIGGER IF NOT EXISTS update_products_timestamp
    AFTER UPDATE ON products
    BEGIN
      UPDATE products SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
    END;

    CREATE TRIGGER IF NOT EXISTS update_orders_timestamp
    AFTER UPDATE ON orders
    BEGIN
      UPDATE orders SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
    END;

    CREATE TRIGGER IF NOT EXISTS update_disputes_timestamp
    AFTER UPDATE ON disputes
    BEGIN
      UPDATE disputes SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
    END;

    CREATE TRIGGER IF NOT EXISTS update_settings_timestamp
    AFTER UPDATE ON settings
    BEGIN
      UPDATE settings SET updated_at = CURRENT_TIMESTAMP WHERE key = NEW.key;
    END;

    CREATE TRIGGER IF NOT EXISTS update_payment_addresses_timestamp
    AFTER UPDATE ON payment_addresses
    BEGIN
      UPDATE payment_addresses SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
    END;
  `);

  // Check if admin user exists, create if not
  const adminExists = await db.get('SELECT id FROM users WHERE username = ?', [process.env.ADMIN_USERNAME || 'admin']);

  if (!adminExists) {
    // Create admin user
    const adminPasswordHash = process.env.ADMIN_PASSWORD_HASH ||
      await bcrypt.hash('admin', 10); // Default password 'admin' if not defined

    await db.run(
      'INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)',
      [process.env.ADMIN_USERNAME || 'admin', adminPasswordHash, 'admin']
    );

    console.log('Admin user created');
  }

  // Initialize default settings if they don't exist
  const defaultSettings = [
    { key: 'site_title', value: process.env.SITE_TITLE || 'Tor Marketplace' },
    { key: 'site_description', value: process.env.SITE_DESCRIPTION || 'A privacy-focused marketplace with cryptocurrency support' },
    { key: 'maintenance_mode', value: 'false' },
    { key: 'theme', value: 'dark' },
    { key: 'tor_only', value: process.env.TOR_ENABLED || 'false' },
    { key: 'bitcoin_enabled', value: process.env.BITCOIN_ENABLED || 'false' },
    { key: 'monero_enabled', value: process.env.MONERO_ENABLED || 'false' },
    { key: 'csp_enabled', value: process.env.CSP_ENABLED || 'true' },
    { key: 'commission_rate', value: '2.5' }, // 2.5% commission on sales
    { key: 'minimum_vendor_reputation', value: '0' }, // Minimum reputation to become vendor
    { key: 'escrow_enabled', value: 'true' }, // Enable escrow by default
    { key: 'pgp_required', value: 'false' }, // Require PGP
  ];

  for (const setting of defaultSettings) {
    const existingSetting = await db.get('SELECT key FROM settings WHERE key = ?', [setting.key]);

    if (!existingSetting) {
      await db.run('INSERT INTO settings (key, value) VALUES (?, ?)', [setting.key, setting.value]);
      console.log(`Setting '${setting.key}' initialized`);
    }
  }

  // Create initial categories
  const categories = [
    { name: 'Digital Goods', slug: 'digital-goods', description: 'Digital products and services' },
    { name: 'Physical Goods', slug: 'physical-goods', description: 'Physical products that require shipping' },
    { name: 'Services', slug: 'services', description: 'Various services offered by vendors' }
  ];

  for (const category of categories) {
    const categoryExists = await db.get('SELECT id FROM categories WHERE slug = ?', [category.slug]);

    if (!categoryExists) {
      await db.run(
        'INSERT INTO categories (name, slug, description) VALUES (?, ?, ?)',
        [category.name, category.slug, category.description]
      );

      console.log(`Category '${category.name}' created`);
    }
  }

  console.log('Database initialized successfully');
};
