import crypto from 'crypto';
import CryptoJS from 'crypto-js';

/**
 * Utility for handling encryption and decryption of sensitive data
 */
export class CryptoUtil {
  private static readonly algorithm = 'aes-256-gcm';
  private static readonly encoding = 'hex';
  private static readonly ivLength = 16; // For AES, this is always 16 bytes
  private static readonly saltLength = 64;
  private static readonly tagLength = 16;
  private static readonly keyLength = 32; // 256 bits
  private static readonly iterations = 100000;

  /**
   * Get the encryption key from environment or generate one
   */
  private static getKey(): Buffer {
    const storedKey = process.env.ENCRYPTION_KEY;

    if (!storedKey) {
      // In production, this would be an error, but for development, we'll generate a key
      console.warn('Encryption key not found in environment. Using a temporary key for development.');
      return crypto.randomBytes(32);
    }

    // Use the stored key (convert from hex to buffer)
    return Buffer.from(storedKey, 'hex');
  }

  /**
   * Encrypt sensitive data
   * @param text Text to encrypt
   * @returns Encrypted data as a string
   */
  static encrypt(text: string): string {
    try {
      // Generate random salt and initialization vector
      const iv = crypto.randomBytes(this.ivLength);
      const salt = crypto.randomBytes(this.saltLength);

      // Derive key using PBKDF2
      const key = crypto.pbkdf2Sync(
        this.getKey(),
        salt,
        this.iterations,
        this.keyLength,
        'sha512'
      );

      // Create cipher
      const cipher = crypto.createCipheriv(this.algorithm, key, iv);

      // Encrypt data
      let encrypted = cipher.update(text, 'utf8', this.encoding);
      encrypted += cipher.final(this.encoding);

      // Get authentication tag
      const tag = cipher.getAuthTag();

      // Combine all parts: salt (64 bytes) + iv (16 bytes) + tag (16 bytes) + encrypted data
      return salt.toString(this.encoding) +
             iv.toString(this.encoding) +
             tag.toString(this.encoding) +
             encrypted;
    } catch (error) {
      console.error('Encryption error:', error);
      throw new Error('Failed to encrypt data');
    }
  }

  /**
   * Decrypt sensitive data
   * @param encryptedData Encrypted data as a string
   * @returns Decrypted text
   */
  static decrypt(encryptedData: string): string {
    try {
      // Convert hex to buffer
      const encryptedBuffer = Buffer.from(encryptedData, this.encoding);

      // Extract salt, iv, tag, and encrypted data
      const salt = encryptedBuffer.slice(0, this.saltLength);
      const iv = encryptedBuffer.slice(this.saltLength, this.saltLength + this.ivLength);
      const tag = encryptedBuffer.slice(this.saltLength + this.ivLength, this.saltLength + this.ivLength + this.tagLength);
      const encrypted = encryptedBuffer.slice(this.saltLength + this.ivLength + this.tagLength);

      // Derive key using PBKDF2
      const key = crypto.pbkdf2Sync(
        this.getKey(),
        salt,
        this.iterations,
        this.keyLength,
        'sha512'
      );

      // Create decipher
      const decipher = crypto.createDecipheriv(this.algorithm, key, iv);
      decipher.setAuthTag(tag);

      // Decrypt data
      let decrypted = decipher.update(encrypted.toString(this.encoding), this.encoding, 'utf8');
      decrypted += decipher.final('utf8');

      return decrypted;
    } catch (error) {
      console.error('Decryption error:', error);
      throw new Error('Failed to decrypt data');
    }
  }

  /**
   * Generate a secure random string (useful for tokens, session IDs, etc.)
   * @param length Length of the random string
   * @returns Random string in hex format
   */
  static generateRandomString(length: number = 32): string {
    return crypto.randomBytes(length).toString('hex');
  }

  /**
   * Hash a password using bcrypt (to be implemented with bcrypt separately)
   * This is just a placeholder - see authService for actual implementation
   */
  static hashPassword(password: string): Promise<string> {
    // This would typically use bcrypt, but we'll just throw here
    // since this should be implemented in the authService
    throw new Error('Use authService.hashPassword instead');
  }

  /**
   * Generate a PGP key pair (simplified version using CryptoJS for demo)
   * In production, this would use a proper PGP library like OpenPGP.js
   */
  static generateSimplifiedKeyPair(): { publicKey: string, privateKey: string } {
    // This is not a real PGP implementation, just a simulation for demonstration
    const passphrase = this.generateRandomString(16);
    const keyData = this.generateRandomString(512);

    // "Encrypt" private key with passphrase
    const privateKey = CryptoJS.AES.encrypt(keyData, passphrase).toString();

    // Public key is just part of the key data (not how real PGP works)
    const publicKey = keyData.substring(0, 256);

    return {
      publicKey: `-----BEGIN PGP PUBLIC KEY BLOCK-----\n${publicKey}\n-----END PGP PUBLIC KEY BLOCK-----`,
      privateKey: `-----BEGIN PGP PRIVATE KEY BLOCK-----\nPassphrase: ${passphrase}\n${privateKey}\n-----END PGP PRIVATE KEY BLOCK-----`
    };
  }

  /**
   * Simplified PGP encryption (not actual PGP - just for demonstration)
   * In production, this would use a proper PGP library
   */
  static simplifiedPgpEncrypt(text: string, publicKey: string): string {
    // Extract the public key data
    const keyData = publicKey
      .replace('-----BEGIN PGP PUBLIC KEY BLOCK-----', '')
      .replace('-----END PGP PUBLIC KEY BLOCK-----', '')
      .trim();

    // Encrypt with the public key data as the password
    return CryptoJS.AES.encrypt(text, keyData).toString();
  }

  /**
   * Simplified PGP decryption (not actual PGP - just for demonstration)
   * In production, this would use a proper PGP library
   */
  static simplifiedPgpDecrypt(encryptedText: string, privateKey: string): string {
    // Extract the private key data and passphrase
    const keyLines = privateKey
      .replace('-----BEGIN PGP PRIVATE KEY BLOCK-----', '')
      .replace('-----END PGP PRIVATE KEY BLOCK-----', '')
      .trim()
      .split('\n');

    const passphrase = keyLines[0].replace('Passphrase: ', '');
    const encryptedKeyData = keyLines.slice(1).join('');

    // Decrypt the private key
    const keyData = CryptoJS.AES.decrypt(encryptedKeyData, passphrase).toString(CryptoJS.enc.Utf8);

    // Use the key data to decrypt the message
    const decrypted = CryptoJS.AES.decrypt(encryptedText, keyData.substring(0, 256));

    return decrypted.toString(CryptoJS.enc.Utf8);
  }
}
