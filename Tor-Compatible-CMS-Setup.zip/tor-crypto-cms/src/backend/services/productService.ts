import { db } from '../models/db';
import crypto from 'crypto';

// Product interface
interface Product {
  id: number;
  title: string;
  slug: string;
  description: string;
  short_description?: string;
  price: number;
  currency: string;
  stock: number;
  vendor_id: number;
  category_id?: number;
  status: 'draft' | 'published' | 'hidden';
  shipping_options?: string;
  digital: boolean;
  featured: boolean;
  created_at: string;
  updated_at: string;
}

// Product create/update interface
interface ProductData {
  title: string;
  description: string;
  short_description?: string;
  price: number;
  currency: string;
  stock: number;
  category_id?: number;
  status: 'draft' | 'published' | 'hidden';
  shipping_options?: string | { [key: string]: any };
  digital: boolean;
  featured?: boolean;
}

// Product with vendor and category data
interface ProductWithDetails extends Product {
  vendor_username: string;
  vendor_reputation: number;
  category_name?: string;
  images?: ProductImage[];
}

// Product image interface
interface ProductImage {
  id: number;
  product_id: number;
  image_path: string;
  main_image: boolean;
  created_at: string;
}

// Search parameters
interface ProductSearchParams {
  query?: string;
  category_id?: number;
  vendor_id?: number;
  min_price?: number;
  max_price?: number;
  currency?: string;
  digital_only?: boolean;
  sort_by?: 'price_asc' | 'price_desc' | 'newest' | 'oldest' | 'popularity';
  page?: number;
  limit?: number;
}

export class ProductService {
  /**
   * Create a new product
   */
  static async createProduct(vendorId: number, data: ProductData): Promise<{ success: boolean; productId?: number; slug?: string; message?: string }> {
    try {
      // Generate a slug from the title
      const slug = this.generateSlug(data.title);

      // Check if slug already exists
      const existingSlug = await db.get('SELECT id FROM products WHERE slug = ?', [slug]);

      if (existingSlug) {
        // Append a random string to make slug unique
        const uniqueSlug = `${slug}-${crypto.randomBytes(4).toString('hex')}`;

        return this.insertProduct(vendorId, data, uniqueSlug);
      }

      return this.insertProduct(vendorId, data, slug);
    } catch (error) {
      console.error('Create product error:', error);
      return { success: false, message: 'Failed to create product' };
    }
  }

  /**
   * Insert a product into the database
   */
  private static async insertProduct(vendorId: number, data: ProductData, slug: string): Promise<{ success: boolean; productId?: number; slug?: string; message?: string }> {
    try {
      // Convert shipping options to JSON string if it's an object
      const shippingOptions = typeof data.shipping_options === 'object'
        ? JSON.stringify(data.shipping_options)
        : data.shipping_options;

      // Insert the product
      const result = await db.run(
        `INSERT INTO products (
          title, slug, description, short_description, price, currency,
          stock, vendor_id, category_id, status, shipping_options,
          digital, featured
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          data.title,
          slug,
          data.description,
          data.short_description || null,
          data.price,
          data.currency,
          data.stock,
          vendorId,
          data.category_id || null,
          data.status,
          shippingOptions || null,
          data.digital ? 1 : 0,
          data.featured ? 1 : 0
        ]
      );

      return {
        success: true,
        productId: result.lastID,
        slug,
        message: 'Product created successfully'
      };
    } catch (error) {
      console.error('Insert product error:', error);
      return { success: false, message: 'Failed to insert product' };
    }
  }

  /**
   * Update a product
   */
  static async updateProduct(productId: number, vendorId: number, data: Partial<ProductData>): Promise<{ success: boolean; message?: string }> {
    try {
      // Check if product exists and belongs to vendor
      const product = await db.get<Product>(
        'SELECT id FROM products WHERE id = ? AND vendor_id = ?',
        [productId, vendorId]
      );

      if (!product) {
        return { success: false, message: 'Product not found or you do not have permission to edit it' };
      }

      // Build update query
      const updates: string[] = [];
      const values: any[] = [];

      if (data.title !== undefined) {
        updates.push('title = ?');
        values.push(data.title);

        // If title changed, update slug
        const newSlug = this.generateSlug(data.title);
        updates.push('slug = ?');
        values.push(newSlug);
      }

      if (data.description !== undefined) {
        updates.push('description = ?');
        values.push(data.description);
      }

      if (data.short_description !== undefined) {
        updates.push('short_description = ?');
        values.push(data.short_description);
      }

      if (data.price !== undefined) {
        updates.push('price = ?');
        values.push(data.price);
      }

      if (data.currency !== undefined) {
        updates.push('currency = ?');
        values.push(data.currency);
      }

      if (data.stock !== undefined) {
        updates.push('stock = ?');
        values.push(data.stock);
      }

      if (data.category_id !== undefined) {
        updates.push('category_id = ?');
        values.push(data.category_id);
      }

      if (data.status !== undefined) {
        updates.push('status = ?');
        values.push(data.status);
      }

      if (data.shipping_options !== undefined) {
        updates.push('shipping_options = ?');
        values.push(typeof data.shipping_options === 'object'
          ? JSON.stringify(data.shipping_options)
          : data.shipping_options);
      }

      if (data.digital !== undefined) {
        updates.push('digital = ?');
        values.push(data.digital ? 1 : 0);
      }

      if (data.featured !== undefined) {
        updates.push('featured = ?');
        values.push(data.featured ? 1 : 0);
      }

      // Add updated_at timestamp
      updates.push('updated_at = CURRENT_TIMESTAMP');

      // If no updates, return success
      if (updates.length === 0) {
        return { success: true, message: 'No changes to update' };
      }

      // Execute update
      await db.run(
        `UPDATE products SET ${updates.join(', ')} WHERE id = ?`,
        [...values, productId]
      );

      return { success: true, message: 'Product updated successfully' };
    } catch (error) {
      console.error('Update product error:', error);
      return { success: false, message: 'Failed to update product' };
    }
  }

  /**
   * Delete a product
   */
  static async deleteProduct(productId: number, vendorId: number): Promise<{ success: boolean; message?: string }> {
    try {
      // Check if product exists and belongs to vendor (or if user is admin)
      const product = await db.get<Product>(
        'SELECT id FROM products WHERE id = ? AND (vendor_id = ? OR ? IN (SELECT id FROM users WHERE role = "admin"))',
        [productId, vendorId, vendorId]
      );

      if (!product) {
        return { success: false, message: 'Product not found or you do not have permission to delete it' };
      }

      // Delete product images first
      await db.run('DELETE FROM product_images WHERE product_id = ?', [productId]);

      // Delete product
      await db.run('DELETE FROM products WHERE id = ?', [productId]);

      return { success: true, message: 'Product deleted successfully' };
    } catch (error) {
      console.error('Delete product error:', error);
      return { success: false, message: 'Failed to delete product' };
    }
  }

  /**
   * Get a product by ID
   */
  static async getProductById(productId: number): Promise<ProductWithDetails | null> {
    try {
      // Get product with vendor and category details
      const product = await db.get<ProductWithDetails>(
        `SELECT p.*,
                u.username as vendor_username,
                u.reputation as vendor_reputation,
                c.name as category_name
         FROM products p
         JOIN users u ON p.vendor_id = u.id
         LEFT JOIN categories c ON p.category_id = c.id
         WHERE p.id = ?`,
        [productId]
      );

      if (!product) {
        return null;
      }

      // Get product images
      const images = await db.all<ProductImage[]>(
        'SELECT * FROM product_images WHERE product_id = ? ORDER BY main_image DESC',
        [productId]
      );

      return {
        ...product,
        images: images || []
      };
    } catch (error) {
      console.error('Get product error:', error);
      return null;
    }
  }

  /**
   * Get a product by slug
   */
  static async getProductBySlug(slug: string): Promise<ProductWithDetails | null> {
    try {
      // Get product with vendor and category details
      const product = await db.get<ProductWithDetails>(
        `SELECT p.*,
                u.username as vendor_username,
                u.reputation as vendor_reputation,
                c.name as category_name
         FROM products p
         JOIN users u ON p.vendor_id = u.id
         LEFT JOIN categories c ON p.category_id = c.id
         WHERE p.slug = ?`,
        [slug]
      );

      if (!product) {
        return null;
      }

      // Get product images
      const images = await db.all<ProductImage[]>(
        'SELECT * FROM product_images WHERE product_id = ? ORDER BY main_image DESC',
        [product.id]
      );

      return {
        ...product,
        images: images || []
      };
    } catch (error) {
      console.error('Get product by slug error:', error);
      return null;
    }
  }

  /**
   * Search for products
   */
  static async searchProducts(params: ProductSearchParams): Promise<{ products: ProductWithDetails[]; total: number; pages: number }> {
    try {
      const {
        query,
        category_id,
        vendor_id,
        min_price,
        max_price,
        currency,
        digital_only,
        sort_by,
        page = 1,
        limit = 10
      } = params;

      // Build WHERE conditions
      const conditions: string[] = ['p.status = "published"'];
      const values: any[] = [];

      if (query) {
        conditions.push('(p.title LIKE ? OR p.description LIKE ? OR p.short_description LIKE ?)');
        const searchTerm = `%${query}%`;
        values.push(searchTerm, searchTerm, searchTerm);
      }

      if (category_id) {
        conditions.push('p.category_id = ?');
        values.push(category_id);
      }

      if (vendor_id) {
        conditions.push('p.vendor_id = ?');
        values.push(vendor_id);
      }

      if (min_price !== undefined) {
        conditions.push('p.price >= ?');
        values.push(min_price);
      }

      if (max_price !== undefined) {
        conditions.push('p.price <= ?');
        values.push(max_price);
      }

      if (currency) {
        conditions.push('p.currency = ?');
        values.push(currency);
      }

      if (digital_only) {
        conditions.push('p.digital = 1');
      }

      // Build ORDER BY clause
      let orderBy = 'p.updated_at DESC';

      if (sort_by === 'price_asc') {
        orderBy = 'p.price ASC';
      } else if (sort_by === 'price_desc') {
        orderBy = 'p.price DESC';
      } else if (sort_by === 'newest') {
        orderBy = 'p.created_at DESC';
      } else if (sort_by === 'oldest') {
        orderBy = 'p.created_at ASC';
      } else if (sort_by === 'popularity') {
        // Placeholder for popularity sorting - would use reviews or sales in a real implementation
        orderBy = '(SELECT COUNT(*) FROM order_items oi WHERE oi.product_id = p.id) DESC, p.updated_at DESC';
      }

      // Calculate offset
      const offset = (page - 1) * limit;

      // Build query
      const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

      // Get total count
      const countResult = await db.get<{ total: number }>(
        `SELECT COUNT(*) as total FROM products p ${whereClause}`,
        values
      );

      const total = countResult?.total || 0;
      const pages = Math.ceil(total / limit);

      // Get products
      const products = await db.all<ProductWithDetails[]>(
        `SELECT p.*,
                u.username as vendor_username,
                u.reputation as vendor_reputation,
                c.name as category_name
         FROM products p
         JOIN users u ON p.vendor_id = u.id
         LEFT JOIN categories c ON p.category_id = c.id
         ${whereClause}
         ORDER BY ${orderBy}
         LIMIT ? OFFSET ?`,
        [...values, limit, offset]
      );

      // Get main image for each product
      for (const product of products) {
        const mainImage = await db.get<ProductImage>(
          'SELECT * FROM product_images WHERE product_id = ? AND main_image = 1 LIMIT 1',
          [product.id]
        );

        product.images = mainImage ? [mainImage] : [];
      }

      return { products, total, pages };
    } catch (error) {
      console.error('Search products error:', error);
      return { products: [], total: 0, pages: 0 };
    }
  }

  /**
   * Add an image to a product
   */
  static async addProductImage(productId: number, vendorId: number, imagePath: string, mainImage: boolean = false): Promise<{ success: boolean; imageId?: number; message?: string }> {
    try {
      // Check if product exists and belongs to vendor
      const product = await db.get<Product>(
        'SELECT id FROM products WHERE id = ? AND vendor_id = ?',
        [productId, vendorId]
      );

      if (!product) {
        return { success: false, message: 'Product not found or you do not have permission to add images' };
      }

      // If this is the main image, unset any existing main image
      if (mainImage) {
        await db.run(
          'UPDATE product_images SET main_image = 0 WHERE product_id = ?',
          [productId]
        );
      }

      // Add image
      const result = await db.run(
        'INSERT INTO product_images (product_id, image_path, main_image) VALUES (?, ?, ?)',
        [productId, imagePath, mainImage ? 1 : 0]
      );

      return {
        success: true,
        imageId: result.lastID,
        message: 'Image added successfully'
      };
    } catch (error) {
      console.error('Add product image error:', error);
      return { success: false, message: 'Failed to add image' };
    }
  }

  /**
   * Delete a product image
   */
  static async deleteProductImage(imageId: number, vendorId: number): Promise<{ success: boolean; message?: string }> {
    try {
      // Check if image exists and belongs to a product owned by the vendor
      const image = await db.get<ProductImage>(
        `SELECT pi.*
         FROM product_images pi
         JOIN products p ON pi.product_id = p.id
         WHERE pi.id = ? AND p.vendor_id = ?`,
        [imageId, vendorId]
      );

      if (!image) {
        return { success: false, message: 'Image not found or you do not have permission to delete it' };
      }

      // Delete image
      await db.run('DELETE FROM product_images WHERE id = ?', [imageId]);

      // If this was the main image, set another image as main if available
      if (image.main_image) {
        const nextImage = await db.get<ProductImage>(
          'SELECT id FROM product_images WHERE product_id = ? LIMIT 1',
          [image.product_id]
        );

        if (nextImage) {
          await db.run(
            'UPDATE product_images SET main_image = 1 WHERE id = ?',
            [nextImage.id]
          );
        }
      }

      return { success: true, message: 'Image deleted successfully' };
    } catch (error) {
      console.error('Delete product image error:', error);
      return { success: false, message: 'Failed to delete image' };
    }
  }

  /**
   * Set a product image as the main image
   */
  static async setMainProductImage(imageId: number, vendorId: number): Promise<{ success: boolean; message?: string }> {
    try {
      // Check if image exists and belongs to a product owned by the vendor
      const image = await db.get<ProductImage>(
        `SELECT pi.*
         FROM product_images pi
         JOIN products p ON pi.product_id = p.id
         WHERE pi.id = ? AND p.vendor_id = ?`,
        [imageId, vendorId]
      );

      if (!image) {
        return { success: false, message: 'Image not found or you do not have permission to modify it' };
      }

      // Unset any existing main image
      await db.run(
        'UPDATE product_images SET main_image = 0 WHERE product_id = ?',
        [image.product_id]
      );

      // Set this image as main
      await db.run(
        'UPDATE product_images SET main_image = 1 WHERE id = ?',
        [imageId]
      );

      return { success: true, message: 'Main image updated successfully' };
    } catch (error) {
      console.error('Set main product image error:', error);
      return { success: false, message: 'Failed to update main image' };
    }
  }

  /**
   * Get all products for a vendor
   */
  static async getVendorProducts(vendorId: number): Promise<Product[]> {
    try {
      const products = await db.all<Product[]>(
        'SELECT * FROM products WHERE vendor_id = ? ORDER BY updated_at DESC',
        [vendorId]
      );

      return products;
    } catch (error) {
      console.error('Get vendor products error:', error);
      return [];
    }
  }

  /**
   * Helper function to generate a slug from a title
   */
  private static generateSlug(title: string): string {
    return title
      .toLowerCase()
      .replace(/[^\w ]+/g, '')
      .replace(/ +/g, '-');
  }
}
