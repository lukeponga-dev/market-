import bcrypt from 'bcrypt';
import { db } from '../models/db';
import { CryptoUtil } from '../utils/cryptoUtil';

// User interface
interface User {
  id: number;
  username: string;
  password_hash: string;
  pgp_public_key?: string;
  email?: string;
  role: 'admin' | 'user' | 'vendor';
  vendor: boolean;
  twofa_secret?: string;
  twofa_enabled: boolean;
  reputation: number;
  created_at: string;
  updated_at: string;
}

// Registration data interface
interface RegistrationData {
  username: string;
  password: string;
  email?: string;
  pgp_public_key?: string;
}

// Login result interface
interface LoginResult {
  success: boolean;
  user?: Omit<User, 'password_hash'>;
  message?: string;
  requireTwoFactor?: boolean;
}

export class AuthService {
  /**
   * Hash a password using bcrypt
   */
  static async hashPassword(password: string): Promise<string> {
    const saltRounds = 10;
    return bcrypt.hash(password, saltRounds);
  }

  /**
   * Compare a password with a hash
   */
  static async comparePassword(password: string, hash: string): Promise<boolean> {
    return bcrypt.compare(password, hash);
  }

  /**
   * Register a new user
   */
  static async register(data: RegistrationData): Promise<{ success: boolean; message?: string; userId?: number }> {
    try {
      // Check if username already exists
      const existingUser = await db.get('SELECT id FROM users WHERE username = ?', [data.username]);

      if (existingUser) {
        return { success: false, message: 'Username already exists' };
      }

      // Check if email already exists (if provided)
      if (data.email) {
        const existingEmail = await db.get('SELECT id FROM users WHERE email = ?', [data.email]);

        if (existingEmail) {
          return { success: false, message: 'Email already exists' };
        }
      }

      // Hash the password
      const passwordHash = await this.hashPassword(data.password);

      // Insert the new user
      const result = await db.run(
        'INSERT INTO users (username, password_hash, email, pgp_public_key, role) VALUES (?, ?, ?, ?, ?)',
        [data.username, passwordHash, data.email || null, data.pgp_public_key || null, 'user']
      );

      return {
        success: true,
        message: 'User registered successfully',
        userId: result.lastID
      };
    } catch (error) {
      console.error('Registration error:', error);
      return { success: false, message: 'Registration failed due to an error' };
    }
  }

  /**
   * Login a user
   */
  static async login(username: string, password: string): Promise<LoginResult> {
    try {
      // Get the user
      const user = await db.get<User>('SELECT * FROM users WHERE username = ?', [username]);

      if (!user) {
        return { success: false, message: 'Invalid username or password' };
      }

      // Verify password
      const passwordValid = await this.comparePassword(password, user.password_hash);

      if (!passwordValid) {
        return { success: false, message: 'Invalid username or password' };
      }

      // Check if 2FA is enabled
      if (user.twofa_enabled) {
        return {
          success: false,
          requireTwoFactor: true,
          message: '2FA code required'
        };
      }

      // Password is valid, return user without password hash
      const { password_hash, ...userWithoutPassword } = user;

      return {
        success: true,
        user: userWithoutPassword
      };
    } catch (error) {
      console.error('Login error:', error);
      return { success: false, message: 'Login failed due to an error' };
    }
  }

  /**
   * Verify a 2FA code
   * This is a simplified version - in production, use a proper 2FA library
   */
  static async verify2FA(userId: number, code: string): Promise<boolean> {
    try {
      // Get the user
      const user = await db.get<User>('SELECT twofa_secret FROM users WHERE id = ?', [userId]);

      if (!user || !user.twofa_secret) {
        return false;
      }

      // In a real implementation, we would use a library like speakeasy to verify the code
      // For simplicity, we're just checking if the code is '123456'
      return code === '123456';
    } catch (error) {
      console.error('2FA verification error:', error);
      return false;
    }
  }

  /**
   * Get a user by ID
   */
  static async getUserById(userId: number): Promise<Omit<User, 'password_hash'> | null> {
    try {
      const user = await db.get<User>('SELECT * FROM users WHERE id = ?', [userId]);

      if (!user) {
        return null;
      }

      // Return user without password hash
      const { password_hash, ...userWithoutPassword } = user;

      return userWithoutPassword;
    } catch (error) {
      console.error('Get user error:', error);
      return null;
    }
  }

  /**
   * Update a user's PGP key
   */
  static async updatePgpKey(userId: number, pgpPublicKey: string): Promise<boolean> {
    try {
      await db.run(
        'UPDATE users SET pgp_public_key = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [pgpPublicKey, userId]
      );

      return true;
    } catch (error) {
      console.error('Update PGP key error:', error);
      return false;
    }
  }

  /**
   * Generate a new PGP key pair for a user
   * Note: In production, the private key should never be stored on the server
   */
  static async generatePgpKeyPair(userId: number): Promise<{ publicKey: string; privateKey: string } | null> {
    try {
      // Generate key pair
      const keyPair = CryptoUtil.generateSimplifiedKeyPair();

      // Update user's public key
      await db.run(
        'UPDATE users SET pgp_public_key = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [keyPair.publicKey, userId]
      );

      return keyPair;
    } catch (error) {
      console.error('Generate PGP key pair error:', error);
      return null;
    }
  }

  /**
   * Enable 2FA for a user
   * This is a simplified version - in production, use a proper 2FA library
   */
  static async enable2FA(userId: number): Promise<{ success: boolean; secret?: string; qrCode?: string }> {
    try {
      // In a real implementation, we would generate a proper secret and QR code
      // For simplicity, we're just using a random string
      const secret = CryptoUtil.generateRandomString(16);

      // Update user
      await db.run(
        'UPDATE users SET twofa_secret = ?, twofa_enabled = 1, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [secret, userId]
      );

      // In a real implementation, we would generate a QR code for the user to scan
      // For now, we'll just return the secret
      return {
        success: true,
        secret,
        qrCode: `otpauth://totp/TorMarketplace:${userId}?secret=${secret}&issuer=TorMarketplace`
      };
    } catch (error) {
      console.error('Enable 2FA error:', error);
      return { success: false };
    }
  }

  /**
   * Disable 2FA for a user
   */
  static async disable2FA(userId: number): Promise<boolean> {
    try {
      await db.run(
        'UPDATE users SET twofa_secret = NULL, twofa_enabled = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [userId]
      );

      return true;
    } catch (error) {
      console.error('Disable 2FA error:', error);
      return false;
    }
  }

  /**
   * Apply to become a vendor
   */
  static async applyForVendor(userId: number): Promise<{ success: boolean; message?: string }> {
    try {
      // Get the user
      const user = await db.get<User>('SELECT * FROM users WHERE id = ?', [userId]);

      if (!user) {
        return { success: false, message: 'User not found' };
      }

      // Check if already a vendor
      if (user.vendor) {
        return { success: false, message: 'User is already a vendor' };
      }

      // Check if user meets the requirements
      const minimumReputation = parseInt(process.env.MINIMUM_VENDOR_REPUTATION || '0', 10);

      if (user.reputation < minimumReputation) {
        return {
          success: false,
          message: `Insufficient reputation. Minimum required: ${minimumReputation}`
        };
      }

      // Check if PGP is required and provided
      if (process.env.PGP_REQUIRED === 'true' && !user.pgp_public_key) {
        return { success: false, message: 'PGP public key is required for vendors' };
      }

      // Update user to vendor status
      await db.run(
        'UPDATE users SET vendor = 1, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [userId]
      );

      return { success: true, message: 'Vendor status approved' };
    } catch (error) {
      console.error('Apply for vendor error:', error);
      return { success: false, message: 'Application failed due to an error' };
    }
  }
}
