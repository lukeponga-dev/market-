import express from 'express';
import { PaymentService } from '../services/paymentService';

const router = express.Router();

// Middleware to check if user is authenticated
const isAuthenticated = (req, res, next) => {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({
      success: false,
      message: 'Not authenticated'
    });
  }
  next();
};

// Generate a new payment address
router.post('/generate', isAuthenticated, async (req, res) => {
  try {
    const { currency, amount, paymentFor, description } = req.body;

    // Validate required fields
    if (!currency || amount === undefined || !paymentFor) {
      return res.status(400).json({
        success: false,
        message: 'Currency, amount, and paymentFor are required'
      });
    }

    // Validate currency
    if (currency !== 'BTC' && currency !== 'XMR') {
      return res.status(400).json({
        success: false,
        message: 'Currency must be BTC or XMR'
      });
    }

    // Validate amount
    if (isNaN(amount) || parseFloat(amount) <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Amount must be a positive number'
      });
    }

    const paymentAddress = await PaymentService.generatePaymentAddress({
      currency,
      amount: parseFloat(amount),
      paymentFor,
      description
    });

    if (!paymentAddress) {
      return res.status(500).json({
        success: false,
        message: 'Failed to generate payment address'
      });
    }

    res.json({
      success: true,
      payment: paymentAddress
    });
  } catch (error) {
    console.error('Generate payment address error:', error);
    res.status(500).json({
      success: false,
      message: 'An error occurred while generating payment address'
    });
  }
});

// Check payment status
router.get('/status/:paymentId', async (req, res) => {
  try {
    const { paymentId } = req.params;

    if (!paymentId) {
      return res.status(400).json({
        success: false,
        message: 'Payment ID is required'
      });
    }

    const payment = await PaymentService.checkPaymentStatus(paymentId);

    if (!payment) {
      return res.status(404).json({
        success: false,
        message: 'Payment not found'
      });
    }

    res.json({
      success: true,
      payment
    });
  } catch (error) {
    console.error('Check payment status error:', error);
    res.status(500).json({
      success: false,
      message: 'An error occurred while checking payment status'
    });
  }
});

// Simulate payment confirmation (for testing only)
router.post('/simulate-confirmation', isAuthenticated, async (req, res) => {
  try {
    const { paymentId } = req.body;

    if (!paymentId) {
      return res.status(400).json({
        success: false,
        message: 'Payment ID is required'
      });
    }

    // Check if there's an actual payment with this ID
    const payment = await PaymentService.checkPaymentStatus(paymentId);

    if (!payment) {
      return res.status(404).json({
        success: false,
        message: 'Payment not found'
      });
    }

    // Simulate confirmation (only in development mode)
    if (process.env.NODE_ENV !== 'development') {
      return res.status(403).json({
        success: false,
        message: 'This endpoint is only available in development mode'
      });
    }

    const success = await PaymentService.simulatePaymentConfirmation(paymentId);

    if (!success) {
      return res.status(500).json({
        success: false,
        message: 'Failed to simulate payment confirmation'
      });
    }

    res.json({
      success: true,
      message: 'Payment confirmed successfully'
    });
  } catch (error) {
    console.error('Simulate payment confirmation error:', error);
    res.status(500).json({
      success: false,
      message: 'An error occurred while simulating payment confirmation'
    });
  }
});

// Get all pending payments (admin only)
router.get('/pending', isAuthenticated, async (req, res) => {
  try {
    // Check if user is admin
    if (req.session.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Admin access required'
      });
    }

    const pendingPayments = await PaymentService.getPendingPayments();

    res.json({
      success: true,
      payments: pendingPayments
    });
  } catch (error) {
    console.error('Get pending payments error:', error);
    res.status(500).json({
      success: false,
      message: 'An error occurred while getting pending payments'
    });
  }
});

// Update payment status (admin only)
router.put('/status/:paymentId', isAuthenticated, async (req, res) => {
  try {
    // Check if user is admin
    if (req.session.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Admin access required'
      });
    }

    const { paymentId } = req.params;
    const { status, confirmations } = req.body;

    if (!paymentId || !status) {
      return res.status(400).json({
        success: false,
        message: 'Payment ID and status are required'
      });
    }

    // Validate status
    if (!['pending', 'confirmed', 'expired', 'completed'].includes(status)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid status. Must be one of: pending, confirmed, expired, completed'
      });
    }

    const success = await PaymentService.updatePaymentStatus(paymentId, status, confirmations);

    if (!success) {
      return res.status(500).json({
        success: false,
        message: 'Failed to update payment status'
      });
    }

    res.json({
      success: true,
      message: 'Payment status updated successfully'
    });
  } catch (error) {
    console.error('Update payment status error:', error);
    res.status(500).json({
      success: false,
      message: 'An error occurred while updating payment status'
    });
  }
});

export default router;
