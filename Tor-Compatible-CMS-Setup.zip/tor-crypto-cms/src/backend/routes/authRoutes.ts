import express from 'express';
import { AuthService } from '../services/authService';
import { CryptoUtil } from '../utils/cryptoUtil';

const router = express.Router();

// Register a new user
router.post('/register', async (req, res) => {
  try {
    const { username, password, email, pgp_public_key } = req.body;

    // Validate required fields
    if (!username || !password) {
      return res.status(400).json({
        success: false,
        message: 'Username and password are required'
      });
    }

    // Validate username length
    if (username.length < 3 || username.length > 30) {
      return res.status(400).json({
        success: false,
        message: 'Username must be between 3 and 30 characters'
      });
    }

    // Validate password strength
    if (password.length < 8) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 8 characters'
      });
    }

    const result = await AuthService.register({
      username,
      password,
      email,
      pgp_public_key
    });

    if (!result.success) {
      return res.status(400).json(result);
    }

    // On successful registration, return success message
    res.status(201).json(result);
  } catch (error) {
    console.error('Register error:', error);
    res.status(500).json({
      success: false,
      message: 'An error occurred during registration'
    });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    // Validate required fields
    if (!username || !password) {
      return res.status(400).json({
        success: false,
        message: 'Username and password are required'
      });
    }

    const result = await AuthService.login(username, password);

    if (!result.success) {
      return res.status(401).json(result);
    }

    // Store user in session
    if (req.session) {
      req.session.userId = result.user?.id;
      req.session.role = result.user?.role;
      req.session.isVendor = result.user?.vendor;
    }

    // Return user data
    res.json(result);
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      message: 'An error occurred during login'
    });
  }
});

// Verify 2FA
router.post('/verify-2fa', async (req, res) => {
  try {
    const { userId, code } = req.body;

    // Validate required fields
    if (!userId || !code) {
      return res.status(400).json({
        success: false,
        message: 'User ID and 2FA code are required'
      });
    }

    const isValid = await AuthService.verify2FA(userId, code);

    if (!isValid) {
      return res.status(401).json({
        success: false,
        message: 'Invalid 2FA code'
      });
    }

    // Get user data
    const user = await AuthService.getUserById(userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Store user in session
    if (req.session) {
      req.session.userId = user.id;
      req.session.role = user.role;
      req.session.isVendor = user.vendor;
    }

    // Return user data
    res.json({
      success: true,
      user,
      message: '2FA verification successful'
    });
  } catch (error) {
    console.error('2FA verification error:', error);
    res.status(500).json({
      success: false,
      message: 'An error occurred during 2FA verification'
    });
  }
});

// Logout
router.post('/logout', (req, res) => {
  if (req.session) {
    req.session.destroy(err => {
      if (err) {
        console.error('Logout error:', err);
        return res.status(500).json({
          success: false,
          message: 'Failed to logout'
        });
      }

      res.json({
        success: true,
        message: 'Logged out successfully'
      });
    });
  } else {
    res.json({
      success: true,
      message: 'No active session'
    });
  }
});

// Get current user
router.get('/me', async (req, res) => {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({
      success: false,
      message: 'Not authenticated'
    });
  }

  try {
    const user = await AuthService.getUserById(req.session.userId);

    if (!user) {
      // Clear invalid session
      req.session.destroy(err => {
        if (err) console.error('Session destroy error:', err);
      });

      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    res.json({
      success: true,
      user
    });
  } catch (error) {
    console.error('Get current user error:', error);
    res.status(500).json({
      success: false,
      message: 'An error occurred while getting user data'
    });
  }
});

// Update PGP key
router.post('/pgp', async (req, res) => {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({
      success: false,
      message: 'Not authenticated'
    });
  }

  try {
    const { pgp_public_key } = req.body;

    if (!pgp_public_key) {
      return res.status(400).json({
        success: false,
        message: 'PGP public key is required'
      });
    }

    const success = await AuthService.updatePgpKey(req.session.userId, pgp_public_key);

    if (!success) {
      return res.status(500).json({
        success: false,
        message: 'Failed to update PGP key'
      });
    }

    res.json({
      success: true,
      message: 'PGP key updated successfully'
    });
  } catch (error) {
    console.error('Update PGP key error:', error);
    res.status(500).json({
      success: false,
      message: 'An error occurred while updating PGP key'
    });
  }
});

// Generate PGP key pair
router.post('/pgp/generate', async (req, res) => {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({
      success: false,
      message: 'Not authenticated'
    });
  }

  try {
    const keyPair = await AuthService.generatePgpKeyPair(req.session.userId);

    if (!keyPair) {
      return res.status(500).json({
        success: false,
        message: 'Failed to generate PGP key pair'
      });
    }

    res.json({
      success: true,
      keyPair,
      message: 'PGP key pair generated successfully. Save your private key securely, it will not be shown again.'
    });
  } catch (error) {
    console.error('Generate PGP key pair error:', error);
    res.status(500).json({
      success: false,
      message: 'An error occurred while generating PGP key pair'
    });
  }
});

// Enable 2FA
router.post('/2fa/enable', async (req, res) => {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({
      success: false,
      message: 'Not authenticated'
    });
  }

  try {
    const result = await AuthService.enable2FA(req.session.userId);

    if (!result.success) {
      return res.status(500).json({
        success: false,
        message: 'Failed to enable 2FA'
      });
    }

    res.json(result);
  } catch (error) {
    console.error('Enable 2FA error:', error);
    res.status(500).json({
      success: false,
      message: 'An error occurred while enabling 2FA'
    });
  }
});

// Disable 2FA
router.post('/2fa/disable', async (req, res) => {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({
      success: false,
      message: 'Not authenticated'
    });
  }

  try {
    const success = await AuthService.disable2FA(req.session.userId);

    if (!success) {
      return res.status(500).json({
        success: false,
        message: 'Failed to disable 2FA'
      });
    }

    res.json({
      success: true,
      message: '2FA disabled successfully'
    });
  } catch (error) {
    console.error('Disable 2FA error:', error);
    res.status(500).json({
      success: false,
      message: 'An error occurred while disabling 2FA'
    });
  }
});

// Apply to become a vendor
router.post('/vendor/apply', async (req, res) => {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({
      success: false,
      message: 'Not authenticated'
    });
  }

  try {
    const result = await AuthService.applyForVendor(req.session.userId);

    if (!result.success) {
      return res.status(400).json(result);
    }

    // Update session
    req.session.isVendor = true;

    res.json(result);
  } catch (error) {
    console.error('Apply for vendor error:', error);
    res.status(500).json({
      success: false,
      message: 'An error occurred while applying for vendor status'
    });
  }
});

export default router;
