import express from 'express';
import { ProductService } from '../services/productService';

const router = express.Router();

// Middleware to check if user is authenticated
const isAuthenticated = (req, res, next) => {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({
      success: false,
      message: 'Not authenticated'
    });
  }
  next();
};

// Middleware to check if user is a vendor
const isVendor = (req, res, next) => {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({
      success: false,
      message: 'Not authenticated'
    });
  }

  if (!req.session.isVendor) {
    return res.status(403).json({
      success: false,
      message: 'Vendor access required'
    });
  }

  next();
};

// Get all products (with search/filter)
router.get('/', async (req, res) => {
  try {
    const {
      query,
      category_id,
      vendor_id,
      min_price,
      max_price,
      currency,
      digital_only,
      sort_by,
      page,
      limit
    } = req.query;

    const searchParams = {
      query: query as string,
      category_id: category_id ? parseInt(category_id as string) : undefined,
      vendor_id: vendor_id ? parseInt(vendor_id as string) : undefined,
      min_price: min_price ? parseFloat(min_price as string) : undefined,
      max_price: max_price ? parseFloat(max_price as string) : undefined,
      currency: currency as string,
      digital_only: digital_only === 'true',
      sort_by: sort_by as any,
      page: page ? parseInt(page as string) : 1,
      limit: limit ? parseInt(limit as string) : 10
    };

    const result = await ProductService.searchProducts(searchParams);

    res.json({
      success: true,
      ...result
    });
  } catch (error) {
    console.error('Search products error:', error);
    res.status(500).json({
      success: false,
      message: 'An error occurred while searching products'
    });
  }
});

// Get product by ID
router.get('/:id', async (req, res) => {
  try {
    const productId = parseInt(req.params.id);

    if (isNaN(productId)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid product ID'
      });
    }

    const product = await ProductService.getProductById(productId);

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    res.json({
      success: true,
      product
    });
  } catch (error) {
    console.error('Get product error:', error);
    res.status(500).json({
      success: false,
      message: 'An error occurred while getting product'
    });
  }
});

// Get product by slug
router.get('/slug/:slug', async (req, res) => {
  try {
    const slug = req.params.slug;

    const product = await ProductService.getProductBySlug(slug);

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    res.json({
      success: true,
      product
    });
  } catch (error) {
    console.error('Get product by slug error:', error);
    res.status(500).json({
      success: false,
      message: 'An error occurred while getting product'
    });
  }
});

// Create a new product (vendor only)
router.post('/', isVendor, async (req, res) => {
  try {
    const {
      title,
      description,
      short_description,
      price,
      currency,
      stock,
      category_id,
      status,
      shipping_options,
      digital,
      featured
    } = req.body;

    // Validate required fields
    if (!title || !description || price === undefined || !currency) {
      return res.status(400).json({
        success: false,
        message: 'Title, description, price, and currency are required'
      });
    }

    // Validate price
    if (isNaN(price) || price <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Price must be a positive number'
      });
    }

    const result = await ProductService.createProduct(req.session.userId, {
      title,
      description,
      short_description,
      price: parseFloat(price),
      currency,
      stock: stock !== undefined ? parseInt(stock) : -1,
      category_id: category_id ? parseInt(category_id) : undefined,
      status: status || 'draft',
      shipping_options,
      digital: !!digital
    });

    if (!result.success) {
      return res.status(400).json(result);
    }

    res.status(201).json(result);
  } catch (error) {
    console.error('Create product error:', error);
    res.status(500).json({
      success: false,
      message: 'An error occurred while creating product'
    });
  }
});

// Update a product (vendor only)
router.put('/:id', isVendor, async (req, res) => {
  try {
    const productId = parseInt(req.params.id);

    if (isNaN(productId)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid product ID'
      });
    }

    const {
      title,
      description,
      short_description,
      price,
      currency,
      stock,
      category_id,
      status,
      shipping_options,
      digital,
      featured
    } = req.body;

    // Prepare update data
    const updateData: any = {};

    if (title !== undefined) updateData.title = title;
    if (description !== undefined) updateData.description = description;
    if (short_description !== undefined) updateData.short_description = short_description;
    if (price !== undefined) updateData.price = parseFloat(price);
    if (currency !== undefined) updateData.currency = currency;
    if (stock !== undefined) updateData.stock = parseInt(stock);
    if (category_id !== undefined) updateData.category_id = category_id ? parseInt(category_id) : null;
    if (status !== undefined) updateData.status = status;
    if (shipping_options !== undefined) updateData.shipping_options = shipping_options;
    if (digital !== undefined) updateData.digital = !!digital;
    if (featured !== undefined) updateData.featured = !!featured;

    // Validate price if provided
    if (price !== undefined && (isNaN(updateData.price) || updateData.price <= 0)) {
      return res.status(400).json({
        success: false,
        message: 'Price must be a positive number'
      });
    }

    const result = await ProductService.updateProduct(productId, req.session.userId, updateData);

    if (!result.success) {
      return res.status(400).json(result);
    }

    res.json(result);
  } catch (error) {
    console.error('Update product error:', error);
    res.status(500).json({
      success: false,
      message: 'An error occurred while updating product'
    });
  }
});

// Delete a product (vendor only)
router.delete('/:id', isVendor, async (req, res) => {
  try {
    const productId = parseInt(req.params.id);

    if (isNaN(productId)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid product ID'
      });
    }

    const result = await ProductService.deleteProduct(productId, req.session.userId);

    if (!result.success) {
      return res.status(400).json(result);
    }

    res.json(result);
  } catch (error) {
    console.error('Delete product error:', error);
    res.status(500).json({
      success: false,
      message: 'An error occurred while deleting product'
    });
  }
});

// Add an image to a product (vendor only)
router.post('/:id/images', isVendor, async (req, res) => {
  try {
    const productId = parseInt(req.params.id);

    if (isNaN(productId)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid product ID'
      });
    }

    const { image_path, main_image } = req.body;

    if (!image_path) {
      return res.status(400).json({
        success: false,
        message: 'Image path is required'
      });
    }

    const result = await ProductService.addProductImage(
      productId,
      req.session.userId,
      image_path,
      !!main_image
    );

    if (!result.success) {
      return res.status(400).json(result);
    }

    res.status(201).json(result);
  } catch (error) {
    console.error('Add product image error:', error);
    res.status(500).json({
      success: false,
      message: 'An error occurred while adding product image'
    });
  }
});

// Delete a product image (vendor only)
router.delete('/images/:id', isVendor, async (req, res) => {
  try {
    const imageId = parseInt(req.params.id);

    if (isNaN(imageId)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid image ID'
      });
    }

    const result = await ProductService.deleteProductImage(imageId, req.session.userId);

    if (!result.success) {
      return res.status(400).json(result);
    }

    res.json(result);
  } catch (error) {
    console.error('Delete product image error:', error);
    res.status(500).json({
      success: false,
      message: 'An error occurred while deleting product image'
    });
  }
});

// Set a product image as the main image (vendor only)
router.put('/images/:id/main', isVendor, async (req, res) => {
  try {
    const imageId = parseInt(req.params.id);

    if (isNaN(imageId)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid image ID'
      });
    }

    const result = await ProductService.setMainProductImage(imageId, req.session.userId);

    if (!result.success) {
      return res.status(400).json(result);
    }

    res.json(result);
  } catch (error) {
    console.error('Set main product image error:', error);
    res.status(500).json({
      success: false,
      message: 'An error occurred while setting main product image'
    });
  }
});

// Get all products for the logged-in vendor
router.get('/vendor/my-products', isVendor, async (req, res) => {
  try {
    const products = await ProductService.getVendorProducts(req.session.userId);

    res.json({
      success: true,
      products
    });
  } catch (error) {
    console.error('Get vendor products error:', error);
    res.status(500).json({
      success: false,
      message: 'An error occurred while getting vendor products'
    });
  }
});

export default router;
