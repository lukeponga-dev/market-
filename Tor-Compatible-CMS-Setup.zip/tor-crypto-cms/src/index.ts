import express from 'express';
import session from 'express-session';
import sqlite3 from 'connect-sqlite3';
import path from 'path';
import cors from 'cors';
import dotenv from 'dotenv';
import { initializeDatabase } from './backend/models/db';
import fs from 'fs';

// Import routes
import authRoutes from './backend/routes/authRoutes';
import productRoutes from './backend/routes/productRoutes';
import paymentRoutes from './backend/routes/paymentRoutes';

// Initialize environment variables
dotenv.config();

// Create SQLite3 session store
const SQLiteStore = sqlite3(session);
const PORT = process.env.PORT || 3000;
const app = express();

// Enable CORS for development
app.use(cors());

// Middleware for secure headers
app.use((req, res, next) => {
  // Remove sensitive headers
  res.removeHeader('X-Powered-By');

  // Set security headers
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'no-referrer');

  // Set Content Security Policy if enabled
  if (process.env.CSP_ENABLED === 'true') {
    res.setHeader(
      'Content-Security-Policy',
      "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self';"
    );
  }

  // Check if Tor-only mode is enabled
  if (process.env.TOR_ENABLED === 'true') {
    // Simple check to see if request likely comes from Tor (not foolproof)
    const isTorRequest = req.headers['x-tor'] === 'true' ||
                          req.headers['x-tor2web'] === 'true' ||
                          req.headers['x-forwarded-for']?.includes('tor');

    // Redirect if not accessing through Tor
    if (!isTorRequest && process.env.NODE_ENV === 'production') {
      return res.status(403).json({
        error: 'This marketplace requires Tor Browser for access. Please use Tor Browser: https://www.torproject.org/'
      });
    }
  }

  next();
});

// Parse JSON and URL-encoded data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Set up session middleware
app.use(
  session({
    store: new SQLiteStore({
      db: 'sessions.db',
      dir: './data',
    }),
    secret: process.env.SESSION_SECRET || 'tor_market_session_secret',
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: process.env.NODE_ENV === 'production',
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000, // 1 day
      sameSite: 'strict',
    },
  })
);

// Create frontend directories if they don't exist
const frontendDir = path.join(__dirname, '../frontend');
if (!fs.existsSync(frontendDir)) {
  fs.mkdirSync(frontendDir, { recursive: true });
}

// Create default index.html if it doesn't exist
const indexPath = path.join(frontendDir, 'index.html');
if (!fs.existsSync(indexPath)) {
  fs.writeFileSync(indexPath, `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>${process.env.SITE_TITLE || 'Tor Marketplace'}</title>
      <style>
        body {
          font-family: Arial, sans-serif;
          background-color: #1a1a1a;
          color: #f0f0f0;
          margin: 0;
          padding: 0;
          display: flex;
          justify-content: center;
          align-items: center;
          min-height: 100vh;
          text-align: center;
        }
        .container {
          max-width: 800px;
          padding: 2rem;
        }
        h1 {
          color: #5d9cec;
        }
        pre {
          background-color: #2a2a2a;
          padding: 1rem;
          border-radius: 4px;
          text-align: left;
          overflow-x: auto;
        }
        a {
          color: #5d9cec;
          text-decoration: none;
        }
        a:hover {
          text-decoration: underline;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <h1>${process.env.SITE_TITLE || 'Tor Marketplace'}</h1>
        <p>${process.env.SITE_DESCRIPTION || 'A privacy-focused marketplace with cryptocurrency support'}</p>

        <h2>API Endpoints</h2>
        <p>This marketplace provides the following API endpoints:</p>

        <h3>Authentication</h3>
        <pre>
POST /api/auth/register - Register a new user
POST /api/auth/login - Login
POST /api/auth/logout - Logout
GET /api/auth/me - Get current user
POST /api/auth/vendor/apply - Apply to become a vendor
        </pre>

        <h3>Products</h3>
        <pre>
GET /api/products - Get all products (with search/filter)
GET /api/products/:id - Get product by ID
GET /api/products/slug/:slug - Get product by slug
POST /api/products - Create a new product (vendor only)
PUT /api/products/:id - Update a product (vendor only)
DELETE /api/products/:id - Delete a product (vendor only)
        </pre>

        <h3>Payments</h3>
        <pre>
POST /api/payments/generate - Generate a new payment address
GET /api/payments/status/:paymentId - Check payment status
        </pre>

        <p>For development purposes, you can also simulate a payment confirmation:</p>
        <pre>
POST /api/payments/simulate-confirmation - Simulate payment confirmation
        </pre>

        <p>Run in test mode with <code>BTC</code> and <code>XMR</code> support.</p>
        <p>This marketplace supports the Tor network for enhanced privacy.</p>
      </div>
    </body>
    </html>
  `);
  console.log('Created default index.html');
}

// Serve static files
app.use(express.static(frontendDir));

// API routes
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/payments', paymentRoutes);

// Catch-all route to serve frontend
app.get('*', (_req, res) => {
  res.sendFile(path.join(frontendDir, 'index.html'));
});

// Error handling middleware
app.use((err, _req, res, _next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

// Start the server
const startServer = async () => {
  try {
    // Create data directory if it doesn't exist
    if (!fs.existsSync('./data')) {
      fs.mkdirSync('./data', { recursive: true });
    }

    // Initialize database
    await initializeDatabase();

    // Start Express server
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Environment: ${process.env.NODE_ENV}`);
      console.log(`Tor only mode: ${process.env.TOR_ENABLED === 'true' ? 'Enabled' : 'Disabled'}`);
      console.log(`Bitcoin payments: ${process.env.BITCOIN_ENABLED === 'true' ? 'Enabled' : 'Disabled'}`);
      console.log(`Monero payments: ${process.env.MONERO_ENABLED === 'true' ? 'Enabled' : 'Disabled'}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

startServer();
