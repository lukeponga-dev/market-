# Cryptocurrency Integration Guide

This document provides detailed information about integrating Bitcoin and Monero cryptocurrency payments into the marketplace.

## Overview

The marketplace supports two cryptocurrencies:

1. **Bitcoin (BTC)**: The most widely-used cryptocurrency
2. **Monero (XMR)**: A privacy-focused cryptocurrency with built-in anonymity features

Both currencies are implemented with a similar pattern:
- Generate unique payment addresses per transaction
- Monitor for incoming payments
- Process confirmations
- Update order statuses

## Configuration

### Bitcoin Configuration

In production, you will need access to a Bitcoin node. Set the following in your `.env` file:

```
BITCOIN_ENABLED=true
BITCOIN_NODE_URL=http://localhost:8332  # Replace with your Bitcoin node URL
BITCOIN_RPC_USER=your_rpc_username
BITCOIN_RPC_PASSWORD=your_rpc_password
```

#### Running Your Own Bitcoin Node

For maximum privacy and control, consider running your own Bitcoin node:

1. Install Bitcoin Core: https://bitcoin.org/en/download
2. Configure `bitcoin.conf`:
```
server=1
rpcuser=your_rpc_username
rpcpassword=your_rpc_password
rpcallowip=127.0.0.1
```
3. Run with pruning enabled to save disk space:
```
bitcoind -prune=550
```

### Monero Configuration

For Monero payments, you'll need access to a Monero wallet RPC:

```
MONERO_ENABLED=true
MONERO_WALLET_RPC_URL=http://localhost:18082  # Replace with your Monero wallet RPC URL
MONERO_WALLET_RPC_USER=your_rpc_username
MONERO_WALLET_RPC_PASSWORD=your_rpc_password
```

#### Running Your Own Monero Wallet RPC

For privacy and security, run your own Monero wallet RPC:

1. Download and install Monero: https://www.getmonero.org/downloads/
2. Create a Monero wallet:
```
monero-wallet-cli --generate-new-wallet your_wallet
```
3. Start the wallet RPC server:
```
monero-wallet-rpc --wallet-file your_wallet --rpc-bind-port 18082 --rpc-login your_rpc_username:your_rpc_password --disable-rpc-login --confirm-external-bind
```

## Implementation Details

### Payment Generation

When a user initiates a payment:

1. The system generates a unique payment ID
2. For Bitcoin, a new address is generated via the RPC call `getnewaddress`
3. For Monero, a new subaddress is generated via the RPC call `create_address`
4. The payment details are stored in the `payment_addresses` table
5. A QR code is generated for easy payment

### Payment Monitoring

In a production environment, you should:

1. Set up a background job (cron job) to check for new payments
2. For Bitcoin, use `listtransactions` and `gettransaction` RPC calls to check for new transactions
3. For Monero, use `get_transfers` RPC call to check for incoming transfers
4. Update the payment status based on confirmations

Example monitoring script for Bitcoin (simplified):
```javascript
// Sample code for monitoring Bitcoin payments
async function checkBitcoinPayments() {
  // Get all pending Bitcoin payments
  const pendingPayments = await PaymentService.getPendingPayments();

  for (const payment of pendingPayments) {
    if (payment.currency !== 'BTC') continue;

    // Check if payment received
    const transactions = await bitcoinRPC('listtransactions', ['*', 10, 0, true]);

    for (const tx of transactions) {
      if (tx.address === payment.address && tx.amount >= payment.amount) {
        // Update payment status based on confirmations
        const status = tx.confirmations >= 3 ? 'confirmed' : 'pending';
        await PaymentService.updatePaymentStatus(payment.payment_id, status, tx.confirmations);

        // If confirmed, process the order
        if (status === 'confirmed') {
          await processOrder(payment.payment_for, payment.payment_id);
        }
      }
    }
  }
}
```

Example monitoring script for Monero (simplified):
```javascript
// Sample code for monitoring Monero payments
async function checkMoneroPayments() {
  // Get all pending Monero payments
  const pendingPayments = await PaymentService.getPendingPayments();

  for (const payment of pendingPayments) {
    if (payment.currency !== 'XMR') continue;

    // Check if payment received
    const transfers = await moneroRPC('get_transfers', {
      in: true,
      account_index: 0
    });

    for (const transfer of transfers.in) {
      if (transfer.address === payment.address && transfer.amount >= payment.amount) {
        // Update payment status based on confirmations
        const status = transfer.confirmations >= 10 ? 'confirmed' : 'pending';
        await PaymentService.updatePaymentStatus(payment.payment_id, status, transfer.confirmations);

        // If confirmed, process the order
        if (status === 'confirmed') {
          await processOrder(payment.payment_for, payment.payment_id);
        }
      }
    }
  }
}
```

### Confirmation Thresholds

For security reasons, we recommend:
- Bitcoin: 3 confirmations (approximately 30 minutes)
- Monero: 10 confirmations (approximately 20 minutes)

You can adjust these thresholds based on your risk tolerance.

## Development Mode

For development and testing, the marketplace includes a simulation mode that doesn't require actual cryptocurrency networks:

1. Generate a payment using the API:
```
POST /api/payments/generate
```

2. Simulate payment confirmation:
```
POST /api/payments/simulate-confirmation
{
  "paymentId": "your_payment_id"
}
```

This allows testing the payment flow without actual cryptocurrency transactions.

## Security Considerations

1. **Private Keys**: Never expose private keys
2. **Node Security**: Secure your cryptocurrency nodes
3. **Confirmation Thresholds**: Higher confirmation requirements for larger payments
4. **Validation**: Always validate payment amounts and addresses
5. **Cold Storage**: Move funds to cold storage regularly
6. **Encryption**: Encrypt sensitive payment data
7. **Unique Addresses**: Always use unique addresses for each payment

## Future Improvements

Potential enhancements to the cryptocurrency integration:

1. Add Lightning Network support for faster Bitcoin payments
2. Implement multi-signature wallets for added security
3. Add more cryptocurrencies (Ethereum, etc.)
4. Implement automatic exchange rate updates
5. Create a more sophisticated monitoring system with alerts
6. Implement HD wallets for better address management

## Troubleshooting

Common issues and solutions:

1. **Connection Issues**: Check your node connection settings
2. **Missing Confirmations**: Ensure your node is properly synced
3. **Payment Not Detected**: Verify address generation is working correctly
4. **Incorrect Amounts**: Check for exchange rate issues
5. **Database Issues**: Verify payment records are being stored correctly

For more help, check the logs and ensure your cryptocurrency nodes are operational.

## Disclaimer

Cryptocurrency integrations carry financial risk. This code is provided for educational purposes only. Always test thoroughly and consider security implications before using in production.
